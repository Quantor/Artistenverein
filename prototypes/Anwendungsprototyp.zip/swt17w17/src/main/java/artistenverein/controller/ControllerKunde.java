package artistenverein.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.salespointframework.useraccount.web.LoggedIn;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import artistenverein.kundenverwaltung.RepositoryKunde;
import artistenverein.kundenverwaltung.RepositoryTermin;
import artistenverein.kundenverwaltung.Termin;
import artistenverein.user.Kunde;


@Controller
public class ControllerKunde 
{
	private final UserAccountManager userAccountManager;
	private final RepositoryKunde kundenRepository;
	private final RepositoryTermin terminRepository;
	
	
	@Autowired
	public ControllerKunde(UserAccountManager userAccountManager, RepositoryKunde kundenRepository, RepositoryTermin terminRepository)
	{
		this.userAccountManager = userAccountManager;
		this.kundenRepository = kundenRepository;
		this.terminRepository = terminRepository;
	}
	
	public UserAccountManager getUserAccountManager()
	{
		return this.userAccountManager;
	}
	
	public RepositoryKunde getKundenRepository()
	{
		return this.kundenRepository;
	}
	
	public RepositoryTermin getTerminRepository()
	{
		return this.terminRepository;
	}
	
	@RequestMapping("/termine")
	public String termine(Model model, @LoggedIn UserAccount userAccount)
	{
		Iterable<Termin> termine = terminRepository.findAll();
		List<Termin> termineZuKunde = new ArrayList<Termin>();
		for(Iterator<Termin> it = termine.iterator(); it.hasNext();)
		{
			Termin termin = it.next();
			if(termin.getKunde().getUserAccount().getId().equals(userAccount.getId()))
			{
				termineZuKunde.add(termin);
			}
		}
		model.addAttribute("terminListe", termineZuKunde);
		return "kundenverwaltung/termine";
	}
	
	@RequestMapping(value = "/kontoverwaltung")
	public String accountmanagement(Model model, @LoggedIn UserAccount userAccount, @RequestParam(value = "datenAendern", defaultValue = "false") String datenAendern,
			@RequestParam(value = "passwort", defaultValue = "false") String passwort, @RequestParam(value = "adresse", defaultValue = "false") String adresse)
	{
		Kunde kunde = findeKundeZuUserAccount(userAccount);
		model.addAttribute("kundenListe", kunde);
		if(datenAendern.equals("true"))
		{
			userAccountManager.changePassword(userAccount, passwort);
			kunde.setAdresse(adresse);
		}
		
		return "kundenverwaltung/kontoverwaltung";
	}
	
	public Kunde findeKundeZuUserAccount(UserAccount userAccount)
	{
		Iterator<Kunde> kunden = kundenRepository.findAll().iterator();
		Kunde kunde = new Kunde();
		while(kunden.hasNext())
		{
			kunde = kunden.next();
			if(kunde.getUserAccount().getId().equals(userAccount.getId()))
			{
				break;
			}
		}
		return kunde;
	}
	
}
