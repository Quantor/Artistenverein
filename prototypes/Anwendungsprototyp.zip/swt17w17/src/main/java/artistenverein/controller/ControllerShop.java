package artistenverein.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import artistenverein.shop.Artikel;
import artistenverein.shop.ArtikelKatalog;
import artistenverein.shop.ArtikelErstellFormular;
import artistenverein.shop.ArtikelManager;

// TODO: Name im EKD anpassen

@Controller
public class ControllerShop {

	private final ArtikelKatalog katalog;
	private final ArtikelManager manager;
	
	ControllerShop(ArtikelKatalog katalog, ArtikelManager manager) {
		this.katalog = katalog;
		this.manager = manager;
	}
	
	@GetMapping("/artikel")
	String artikelKatalog(Model model) {
		model.addAttribute("katalog", katalog.findAll());
		model.addAttribute("title", "catalog.item.title");
		return "Shop/Artikelkatalog";
	}
	
	@GetMapping("/artikel/{artikel}")
	String detail(@PathVariable Artikel artikel, Model model) {
		model.addAttribute("artikel", artikel);
		return "Shop/artikelDetail";
	}
	
	@PostMapping("/artikelErstellen")
	String erstelleNeu(@ModelAttribute("formular") @Valid ArtikelErstellFormular formular, BindingResult ergebnis) {
		if (ergebnis.hasErrors()) {
			return "Shop/artikelErstellen";
		}
		manager.erstelleArtikel(formular);	
		return "redirect:/artikel";
	}
	
	@GetMapping("/artikelErstellen")
	String erstelle(Model model) {
		model.addAttribute("formular", new ArtikelErstellFormular());
		return "Shop/artikelErstellen";
	}
	
	@GetMapping("/artikel/{artikel}/bearbeiten")
	String bearbeiteExistierend(@PathVariable Artikel artikel, Model model) {	
		model.addAttribute("artikel", artikel);
		model.addAttribute("formular", new ArtikelErstellFormular());
		return "Shop/artikelBearbeiten";
	}
	
	@PostMapping("/artikel/{artikel}/bearbeiten")
	String bearbeite(@PathVariable Artikel artikel, @ModelAttribute("formular") @Valid ArtikelErstellFormular formular, BindingResult ergebnis) {
		if (ergebnis.hasErrors()) {
			return "Shop/artikelBearbeiten";
		}	
		manager.bearbeiteArtikel(artikel, formular);	
		return "redirect:/artikel/{artikel}";
	}
}
