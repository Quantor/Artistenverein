/*
 * Copyright 2014-2015 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package artistenverein.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import artistenverein.personalverwaltung.ManagerArtist;
import artistenverein.personalverwaltung.FormArtistRegistration;
import artistenverein.user.Artist;

@Controller
public class ControllerPersonenverwaltung {

	private final ManagerArtist artistManagement;

	@Autowired
	ControllerPersonenverwaltung(ManagerArtist artistManagement) {

		Assert.notNull(artistManagement, "artistManagement must not be null!");

		this.artistManagement = artistManagement;
	}

	
	//###Indexseite	
	@GetMapping("/personalverwaltung")
	public String personalverwaltung(Model model) {
		model.addAttribute("artistList", artistManagement.findAllArtist());

		return "Personenverwaltung/personalverwaltung";
	}
	
	//###Seiten für Gruppen
	//gruppenÜbersicht
	@GetMapping("/personalverwaltung/gruppen/uebersicht")
	public String gruppen(Model model) {

		model.addAttribute("gruppenList", artistManagement.findAllGruppen());
		return "Personenverwaltung/gruppe/uebersicht";

	}

	
	//###Seiten für Artisten
	
	@GetMapping("/personalverwaltung/artist/registrieren")
	public String addArtist(Model model) {
		return "personenverwaltung/artist/registrieren";
	}

	@PostMapping("/personalverwaltung/artist/registrieren")
	String registrieren(@RequestParam("name") String name, @RequestParam("passwort") String passwort,
			@RequestParam("nachname") String nachname, @RequestParam("vorname") String vorname,
			@RequestParam("email") String email, Model model) {

		artistManagement.createArtist(new ArtistRegistration(name, passwort, nachname, vorname, email));

		return "Personenverwaltung/ok";
	}

	@PostMapping("/personalverwaltung/artist/bearbeiten")
	String bearbeiten(@RequestParam("artistUsername") String artistUsername, Model model) {
		System.out.println(artistUsername);
		for (Artist artist : artistManagement.findAllArtist()) {

			if (artist.getUserAccount().getUsername().equals(artistUsername)) {
				model.addAttribute("selectedArtist", artist);

				return "Personenverwaltung/artist/bearbeiten";
			}

		}

		return "Personenverwaltung/artist/bearbeiten";
	}

	
	@PostMapping("/personalverwaltung/artist/berarbeiten")
	String artistBerarbeiten(@RequestParam("name") String name, String passwort,
			@RequestParam("nachname") String nachname, @RequestParam("vorname") String vorname,
			@RequestParam("email") String email, Model model) {

		for (Artist artist : artistManagement.findAllArtist()) {
			if (artist.getUserAccount().getUsername().equals(name)) {
				artist.getUserAccount().setEmail(email);
				artist.getUserAccount().setFirstname(vorname);
				artist.getUserAccount().setLastname(nachname);
				artistManagement.save(artist);

			}
		}

		return "Personenverwaltung/ok";
	}

	public class ArtistRegistration implements FormArtistRegistration {

		private String id;
		private String passwort;
		private String nachname;
		private String vorname;
		private String email;
		private String name;

		public ArtistRegistration(String name, String passwort, String nachname, String vorname, String email) {
			this.name = name;
			this.passwort = passwort;
			this.nachname = nachname;
			this.vorname = vorname;
			this.email = email;

		}

		@Override
		public String getId() {

			return id;
		}

		@Override
		public String getPassword() {

			return passwort;
		}

		@Override
		public String getAddress() {

			return null;
		}

		@Override
		public String getNachname() {

			return nachname;
		}

		@Override
		public String getVorname() {

			return vorname;
		}

		@Override
		public String getemail() {

			return email;
		}

		@Override
		public String getName() {

			return name;
		}

	}

}
