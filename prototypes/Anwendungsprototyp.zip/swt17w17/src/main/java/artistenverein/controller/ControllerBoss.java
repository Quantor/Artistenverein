/*
 * Copyright 2013-2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package artistenverein.controller;

import org.salespointframework.inventory.Inventory;
import org.salespointframework.inventory.InventoryItem;
import org.salespointframework.order.Order;
import org.salespointframework.order.OrderManager;
import org.salespointframework.quantity.Quantity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import artistenverein.inventarverwaltung.Artistenzeug;

import java.util.Collection;

// Straight forward?

@Controller
@PreAuthorize("hasRole('ROLE_BOSS')") //No Authorization at the moment
class ControllerBoss {

	private final OrderManager<Order> orderManager;
	private final Inventory<InventoryItem> inventory;

	@Autowired
	public ControllerBoss(OrderManager<Order> orderManager, Inventory<InventoryItem> inventory) {
		this.orderManager = orderManager;
		this.inventory = inventory;
	}

    @RequestMapping("/inventarverwaltung")
    public String stock(Model model) {
        model.addAttribute("stock", inventory.findAll());

        return "Inventarverwaltung/stock";
    }

	@RequestMapping(value = "/nachbestellung", method = RequestMethod.POST)
	//@RequestMapping("/stock") //there is nothing else so / is better right now
	public String stock(Model model, @RequestParam String action, @RequestParam("item") Artistenzeug[] artistenzeug, @RequestParam("number") Long[] number) {

		System.out.println(action);
		if (action.equals("All")) {
            for (InventoryItem i : inventory.findAll()) {
                for (int j=0; j<artistenzeug.length; j++) {
                    System.out.println(artistenzeug[j]);
                    if (i.getProduct().equals(artistenzeug[j])) {
                        i.increaseQuantity(Quantity.of(number[j]));
                        inventory.save(i);
                        break;
                    }
                }
            }
        } else {
            for (InventoryItem i: inventory.findAll())
            {
                if (i.getProduct().getId().toString().equals(action))
                {
                	
                    for (int j=0; j<artistenzeug.length; j++) {
                    	if(artistenzeug[j] == null) {
                    		System.out.println("Inventaritem in artistenzeug nicht im Initializer.");
                    		continue;
                    	}
                    	
                        if (artistenzeug[j].getId().toString().equals(action)) {
                            i.increaseQuantity(Quantity.of(number[j]));
                            inventory.save(i);
                        }
                    }
                }
            }
        }
		model.addAttribute("stock", inventory.findAll());

		return "Inventarverwaltung/stock";
	}
}
