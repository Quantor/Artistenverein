package artistenverein.controller;

import static org.salespointframework.core.Currencies.EURO;

import javax.validation.Valid;

import org.javamoney.moneta.Money;
import org.salespointframework.inventory.Inventory;
import org.salespointframework.inventory.InventoryItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import artistenverein.veranstaltungen.FormNeueVeranstaltung;
import artistenverein.veranstaltungen.EntitiyVeranstaltung;
import artistenverein.veranstaltungen.VeranstaltungsKatalog;
import artistenverein.veranstaltungen.EntitiyVeranstaltung.VeranstaltungsType;

@Controller
class ControlerVeranstaltungen {

	private final VeranstaltungsKatalog veranstaltungsKatalog;
	private final MessageSourceAccessor messageSourceAccessor;
	private VeranstaltungsType vt;

	@Autowired
	public ControlerVeranstaltungen(VeranstaltungsKatalog veranstaltungsKatalog, Inventory<InventoryItem> inventory,
			MessageSource messageSource) {
		this.veranstaltungsKatalog = veranstaltungsKatalog;
		this.messageSourceAccessor = new MessageSourceAccessor(messageSource);
		this.vt = VeranstaltungsType.SHOW;
	}

	@RequestMapping("/workshops")
	public String workshops(Model model) {
		model.addAttribute("katalog", veranstaltungsKatalog.findByType(VeranstaltungsType.WORKSHOP));
		model.addAttribute("title", messageSourceAccessor.getMessage("katalog.workshop.title"));
		this.vt = VeranstaltungsType.WORKSHOP;
		
		return "veranstaltungen/veranstaltungskatalog";
	}

	@RequestMapping("/shows")
	public String blurayCatalog(Model model) {
		model.addAttribute("katalog", veranstaltungsKatalog.findByType(VeranstaltungsType.SHOW));
		model.addAttribute("title", messageSourceAccessor.getMessage("katalog.show.title"));
		this.vt = VeranstaltungsType.SHOW;

		return "veranstaltungen/veranstaltungskatalog";
	}
	
	@RequestMapping("/detail/{pid}")
	public String detail(@PathVariable("pid") EntitiyVeranstaltung veranstaltung, Model model) {
		model.addAttribute("veranstaltung", veranstaltung);

		return "veranstaltungen/detail";
	}
	
	
	@RequestMapping("/add")
	public String erstelleNeueVeransteltung(@ModelAttribute("neueVeransteltung") @Valid FormNeueVeranstaltung neueVeranstaltung,
			BindingResult result) {

		if (result.hasErrors()) {
			return "veranstaltungen/addFormular";
		}
		
		int preis = Integer.parseInt(neueVeranstaltung.getPreis());
		int dauer = Integer.parseInt(neueVeranstaltung.getDauer());
		veranstaltungsKatalog.save(new EntitiyVeranstaltung(neueVeranstaltung.getName(),Money.of(preis,EURO),
				neueVeranstaltung.getBeschreibung(), dauer,vt));

		return "index";
	}

	@RequestMapping("/neu")
	public String register(Model model) {
		model.addAttribute("neueVeranstaltung", new FormNeueVeranstaltung());
		return "veranstaltungen/addFormular";
	}
	

}
