package artistenverein.kundenverwaltung;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.salespointframework.useraccount.UserAccount;

import artistenverein.user.Kunde;

@Entity
public class Termin {
	
	private @Id @GeneratedValue long id;
	
	private String veranstaltung;
	private LocalDateTime datum;
	@OneToOne
	private Kunde kunde;
	

	public Termin() {}
	
	public Termin(String veranstaltung, LocalDateTime datum, Kunde kunde)
	{
		this.veranstaltung = veranstaltung;
		this.datum = datum;
		this.kunde = kunde;
	}
	
	public String getVeranstaltung()
	{
		return this.veranstaltung;
	}
	
	public LocalDateTime getDatum()
	{
		return this.datum;
	}
	
	public Kunde getKunde()
	{
		return this.kunde;
	}
}