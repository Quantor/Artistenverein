package artistenverein.kundenverwaltung;


import org.springframework.data.repository.CrudRepository;

import artistenverein.user.Kunde;

public interface RepositoryKunde extends CrudRepository<Kunde, Long> {}

