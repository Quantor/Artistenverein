package artistenverein.kundenverwaltung;

import org.springframework.data.repository.CrudRepository;

public interface RepositoryTermin extends CrudRepository<Termin, Long>{

}
