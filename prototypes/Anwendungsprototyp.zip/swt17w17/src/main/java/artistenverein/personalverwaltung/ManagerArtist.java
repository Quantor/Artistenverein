/*
 * Copyright 2017 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package artistenverein.personalverwaltung;

import org.salespointframework.core.Streamable;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import artistenverein.user.Artist;

@Service
@Transactional
public class ManagerArtist {

	private final RepositoryArist artists;
	private final RepositoryArtistengruppe gruppen;
	private final UserAccountManager userAccounts;

	ManagerArtist(RepositoryArist artists, UserAccountManager userAccounts,RepositoryArtistengruppe gruppen) {

		Assert.notNull(artists, "CustomerRepository must not be null!");
		Assert.notNull(userAccounts, "UserAccountManager must not be null!");

		this.artists = artists;
		this.userAccounts = userAccounts;
		this.gruppen = gruppen;
	}

	public Artist createArtist(FormArtistRegistration form) {

		Assert.notNull(form, "Registration form must not be null!");

		UserAccount userAccount = userAccounts.create(form.getName(), form.getPassword(), Role.of("ROLE_CUSTOMER"));
		userAccount.setEmail(form.getemail());
		userAccount.setLastname(form.getNachname());
		userAccount.setFirstname(form.getVorname());

		return artists.save(new Artist(userAccount));
	}

	
	public EntitiyArtistengruppe createGruppe(FormArtistRegistration form) {
		
		return gruppen.save(new EntitiyArtistengruppe(form.getName()));
		
	}
	
	public Streamable<Artist> findAllArtist() {
		return Streamable.of(artists.findAll());
	}
	
	public Streamable<EntitiyArtistengruppe> findAllGruppen() {
		return Streamable.of(gruppen.findAll());
	}

	public void save(Artist artist) {
		artists.save(artist);
		
	}

	
	
}

