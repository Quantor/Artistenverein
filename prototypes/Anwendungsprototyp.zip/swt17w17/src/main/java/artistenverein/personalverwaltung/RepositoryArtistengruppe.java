
package artistenverein.personalverwaltung;

import org.springframework.data.repository.CrudRepository;


public interface RepositoryArtistengruppe extends CrudRepository<EntitiyArtistengruppe, Long> {}
