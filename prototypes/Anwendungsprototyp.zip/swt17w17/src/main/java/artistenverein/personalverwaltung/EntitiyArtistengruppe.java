package artistenverein.personalverwaltung;

import java.util.ArrayList;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import artistenverein.user.Artist;

@Entity
public class EntitiyArtistengruppe {

	private @Id @GeneratedValue long id;
	private ArrayList<Artist> mitglieder;

	private String name;

	@SuppressWarnings("unused")
	private EntitiyArtistengruppe() {
	}

	public EntitiyArtistengruppe(String name) {
		mitglieder = new ArrayList<Artist>();
		this.name = name;
	}

	public boolean addArtist(Artist a) {
		return mitglieder.add(a);
	}

	public boolean removeArtist(Artist a) {
		return mitglieder.remove(a);
	}

	public ArrayList<Artist> getMitglieder() {
		return mitglieder;
	}

	public String getName() {
		return name;
	}

	public long getId() {
		return id;
	}

}
