package artistenverein.shop;

import org.javamoney.moneta.Money;
import org.salespointframework.core.DataInitializer;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import static org.salespointframework.core.Currencies.EURO;

@Component
@Order(20)
class InitializerArtikelKatalog implements DataInitializer{

	private final ArtikelKatalog artikelKatalog;
	
	InitializerArtikelKatalog(ArtikelKatalog artikelKatalog) {
		
		Assert.notNull(artikelKatalog, "ItemCatalog must not be null!");
		
		this.artikelKatalog = artikelKatalog; 
	}
	
	@Override
	public void initialize() {
		
		if (artikelKatalog.findAll().iterator().hasNext() ) {
			return;
		}
		
		artikelKatalog.save(new Artikel("Fackel", "fac", Money.of(9.99, EURO)));
		artikelKatalog.save(new Artikel("Pois", "poi", Money.of(14.99, EURO)));
		artikelKatalog.save(new Artikel("Diabolo", "dia", Money.of(12.99, EURO)));
		
	}
}
