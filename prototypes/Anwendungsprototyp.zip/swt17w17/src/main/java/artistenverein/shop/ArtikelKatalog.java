package artistenverein.shop;

import org.salespointframework.catalog.Catalog;

public interface ArtikelKatalog extends Catalog<Artikel> {

}
