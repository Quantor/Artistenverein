package artistenverein.shop;

import static org.salespointframework.core.Currencies.EURO;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.javamoney.moneta.Money;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import artistenverein.controller.ControllerShop;

@Service
public class ArtikelManager {

	private final ArtikelKatalog katalog;

	ArtikelManager(ArtikelKatalog katalog) {

		Assert.notNull(katalog, "CustomerRepository must not be null!");

		this.katalog = katalog;
	}

	public Artikel erstelleArtikel(ArtikelErstellFormular formular) {

		Assert.notNull(formular, "Registration form must not be null!");
		
		String bild = formular.getBild().getOriginalFilename();
		String[] tokens = bild.split("\\.(?=[^\\.]+$)");
		
		Path pfad = Paths.get("static", "resources", "img");
		try {
			pfad = Paths.get(ControllerShop.class.getProtectionDomain().getCodeSource().getLocation().toURI()).resolve(pfad).resolve(bild);
			Files.copy(formular.getBild().getInputStream(), pfad, StandardCopyOption.REPLACE_EXISTING);
		} catch (URISyntaxException e) {
			tokens[0] = "noimage";
			e.printStackTrace();
		} catch (IOException e) {
			tokens[0] = "noimage";
			e.printStackTrace();
		}
		
		Artikel artikel = new Artikel(formular.getName(), tokens[0], Money.of(new BigDecimal(formular.getPreis()), EURO));
		
		return katalog.save(artikel);

	}
	
	public Artikel bearbeiteArtikel(Artikel artikel, ArtikelErstellFormular formular) {
		
		if(!(formular.getBild().getOriginalFilename().isEmpty())) {
			String bild = formular.getBild().getOriginalFilename();
			String[] tokens = bild.split("\\.(?=[^\\.]+$)");
			artikel.setBild(tokens[0]);
			Path path = Paths.get("static", "resources", "img");
			try {
				path = Paths.get(ControllerShop.class.getProtectionDomain().getCodeSource().getLocation().toURI()).resolve(path).resolve(bild);
				Files.copy(formular.getBild().getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				artikel.setBild(tokens[0]);
			} catch (URISyntaxException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		artikel.setName(formular.getName());
		artikel.setPrice(Money.of(new BigDecimal(formular.getPreis()), EURO));
		return katalog.save(artikel);
	}

}
