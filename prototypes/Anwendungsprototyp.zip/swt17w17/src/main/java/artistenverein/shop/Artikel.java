package artistenverein.shop;

import javax.persistence.Entity;

import org.javamoney.moneta.Money;
import org.salespointframework.catalog.Product;

@Entity
public class Artikel extends Product{
	
	private static final long serialVersionUID = 3602164805477720502L;
	
	private String bild;
	
	@SuppressWarnings("unused")
	private Artikel() {}
	
	public Artikel(String name, String bild, Money preis) {
		
		super(name, preis);
		
		this.bild = bild;
	}
	
	public String getBild() {		
		return bild;		
	}
	
	public void setBild(String bild) {
		this.bild = bild;
	}
}
