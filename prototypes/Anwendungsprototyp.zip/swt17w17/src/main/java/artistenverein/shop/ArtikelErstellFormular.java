package artistenverein.shop;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;

public class ArtikelErstellFormular {

	@NotEmpty(message = "{ItemCreationForm.name.NotEmpty}")//
	private String name;

	@NotEmpty(message = "{ItemCreationForm.price.NotEmpty}")//
	private String preis;

	//@NotEmpty(message = "{ItemCreationForm.image.NotEmpty}")//
	private MultipartFile bild;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPreis() {
		return preis;
	}

	public void setPreis(String preis) {
		this.preis = preis;
	}

	public MultipartFile getBild() {
		return bild;
	}

	public void setBild(MultipartFile bild) {
		this.bild = bild;
	}
}
