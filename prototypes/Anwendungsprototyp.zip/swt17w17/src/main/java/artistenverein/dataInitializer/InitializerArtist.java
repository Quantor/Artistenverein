/*
q * Copyright 2017 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package artistenverein.dataInitializer;

import java.time.LocalDateTime;
import java.util.Arrays;

import org.salespointframework.core.DataInitializer;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import artistenverein.kundenverwaltung.RepositoryKunde;
import artistenverein.kundenverwaltung.RepositoryTermin;
import artistenverein.kundenverwaltung.Termin;
import artistenverein.personalverwaltung.EntitiyArtistengruppe;
import artistenverein.personalverwaltung.RepositoryArist;
import artistenverein.personalverwaltung.RepositoryArtistengruppe;
import artistenverein.user.Artist;
import artistenverein.user.Kunde;

/**
 * Initalizes {@link Customer}s.
 * 
 * @author Oliver Gierke
 */
@Component
@Order(10)
class InitializerArtist implements DataInitializer {

	private final UserAccountManager userAccountManager;
	private final RepositoryArist customerRepository;
	private final RepositoryArtistengruppe gruppenRepository;
	private final RepositoryKunde kundenRepository;
	private final RepositoryTermin terminRepository;

	/**
	 * @param userAccountManager
	 * @param customerRepository
	 */
	InitializerArtist(UserAccountManager userAccountManager, RepositoryArist customerRepository,
			RepositoryArtistengruppe gruppenRepository, RepositoryKunde kundenRepository, RepositoryTermin terminRepository) {

		Assert.notNull(customerRepository, "CustomerRepository must not be null!");
		Assert.notNull(userAccountManager, "UserAccountManager must not be null!");
		Assert.notNull(kundenRepository, "CustomerRepository must not be null!");
		Assert.notNull(terminRepository, "Meetings must not be null!");

		this.userAccountManager = userAccountManager;
		this.customerRepository = customerRepository;
		this.gruppenRepository = gruppenRepository;
		this.kundenRepository = kundenRepository;	
		this.terminRepository = terminRepository;
	}
	


	@Override
	public void initialize() {

		if (userAccountManager.findByUsername("boss").isPresent()) {
			return;
		}

		UserAccount bossAccount = userAccountManager.create("boss", "123", Role.of("ROLE_BOSS"));
		userAccountManager.save(bossAccount);

		Role customerRole = Role.of("ROLE_ARTIST");

		UserAccount ua1 = userAccountManager.create("genji", "123", customerRole);
		ua1.setEmail("NeedHealing@gmail.de");
		ua1.setLastname("Shimada");
		ua1.setFirstname("Genji");

		UserAccount ua2 = userAccountManager.create("lucio", "123", customerRole);
		ua2.setEmail("boostio@web.de");
		ua2.setLastname("Correia ");
		ua2.setFirstname("Lúcio");

		UserAccount ua3 = userAccountManager.create("beepBop", "123", customerRole);
		ua3.setEmail("playOfTheGame@gmail.de");
		ua3.setLastname("Bastion");
		ua3.setFirstname("Sepp");

		UserAccount ua4 = userAccountManager.create("cowboy", "123", customerRole);
		ua4.setEmail("highN00n@gmail.com");
		ua4.setLastname("McCree");
		ua4.setFirstname("Jesse");

		UserAccount ua5 = userAccountManager.create("mercy", "123", customerRole);
		ua5.setEmail("mercyGirlXXX@web.de");
		ua5.setLastname("Ziegler");
		ua5.setFirstname("Angela");

		UserAccount ua6 = userAccountManager.create("ananas", "123", customerRole);
		ua6.setEmail("NanoGranny@gmail.de");
		ua6.setLastname("Amari");
		ua6.setFirstname("Ana ");

		UserAccount ua7 = userAccountManager.create("mecha", "123", customerRole);
		ua7.setEmail("progamer@gmail.de");
		ua7.setLastname("Song");
		ua7.setFirstname("Hana ");

		UserAccount ua8 = userAccountManager.create("fatguy", "123", customerRole);
		ua8.setEmail("wholehog@freemail.de");
		ua8.setLastname("Rutledge");
		ua8.setFirstname("Mako ");

		UserAccount ua9 = userAccountManager.create("MrRobot", "123", customerRole);
		ua9.setEmail("MrRobot@evilcorp.de");
		ua9.setLastname("Zenyatta");
		ua9.setFirstname("Tekhartha");

		UserAccount ua10 = userAccountManager.create("doom", "123", customerRole);
		ua10.setEmail("doom@gmail.de");
		ua10.setLastname("Ogundimu");
		ua10.setFirstname("Akande ");

		Artist c1 = new Artist(ua1);
		Artist c2 = new Artist(ua2);
		Artist c3 = new Artist(ua3);
		Artist c4 = new Artist(ua4);
		Artist c5 = new Artist(ua5);
		Artist c6 = new Artist(ua6);
		Artist c7 = new Artist(ua7);
		Artist c8 = new Artist(ua8);
		Artist c9 = new Artist(ua9);
		Artist c10 = new Artist(ua10);

		EntitiyArtistengruppe g1 = new EntitiyArtistengruppe("Feuerspucker");
		EntitiyArtistengruppe g2 = new EntitiyArtistengruppe("Trullerdorfer Sackhüpfer");
		EntitiyArtistengruppe g3 = new EntitiyArtistengruppe("Schwertschluckis");

		customerRepository.save(Arrays.asList(c1, c2, c3, c4, c5, c6, c7, c8, c9, c10));
		gruppenRepository.save(Arrays.asList(g1, g2, g3));

		customerRole = Role.of("ROLE_CUSTOMER");

		UserAccount u1 = userAccountManager.create("hans", "123", customerRole);
		UserAccount u2 = userAccountManager.create("dextermorgan", "123", customerRole);
		UserAccount u3 = userAccountManager.create("earlhickey", "123", customerRole);
		UserAccount u4 = userAccountManager.create("mclovinfogell", "123", customerRole);

		Kunde k1 = new Kunde(u1, "wurst");
		Kunde k2 = new Kunde(u2, "Miami-Dade County");
		Kunde k3 = new Kunde(u3, "Camden County - Motel");
		Kunde k4 = new Kunde(u4, "Los Angeles");

		// (｡◕‿◕｡)
		// Zu faul um save 4x am Stück aufzurufen :)
		kundenRepository.save(Arrays.asList(k1, k2, k3, k4));
		
		LocalDateTime date = LocalDateTime.of(2017, 12, 24, 19, 30);
		LocalDateTime date1 = LocalDateTime.of(2017, 12, 31, 23, 59);
		
		Termin meeting0 = new Termin("Weihnachtsfeierveranstaltung", date, k1);
		Termin meeting1 = new Termin("Silvesterveranstaltung", date1, k1);
		
		terminRepository.save(Arrays.asList(meeting0, meeting1));
		System.out.println(terminRepository.findAll());

	}
}
