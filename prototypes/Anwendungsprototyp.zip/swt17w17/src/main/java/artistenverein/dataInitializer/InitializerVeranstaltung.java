package artistenverein.dataInitializer;

import static org.salespointframework.core.Currencies.*;


import org.javamoney.moneta.Money;
import org.salespointframework.core.DataInitializer;
import org.salespointframework.inventory.Inventory;
import org.salespointframework.inventory.InventoryItem;
import org.salespointframework.quantity.Quantity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import artistenverein.veranstaltungen.EntitiyVeranstaltung;
import artistenverein.veranstaltungen.VeranstaltungsKatalog;
import artistenverein.veranstaltungen.EntitiyVeranstaltung.VeranstaltungsType;


@Component
public class InitializerVeranstaltung implements DataInitializer {
	private final Inventory<InventoryItem> inventory;
	private final VeranstaltungsKatalog veranstaltungskatalog;

	@Autowired
	public InitializerVeranstaltung(VeranstaltungsKatalog veranstaltungskatalog, Inventory<InventoryItem> inventory) {

		Assert.notNull(inventory, "Inventory must not be null!");
		Assert.notNull(veranstaltungskatalog, "VideoCatalog must not be null!");

		this.inventory = inventory;
		this.veranstaltungskatalog = veranstaltungskatalog;
	}

	@Override
	public void initialize() {

		initializeCatalog(veranstaltungskatalog, inventory);
	}

	private void initializeCatalog(VeranstaltungsKatalog veranstaltungskatalog, Inventory<InventoryItem> inventory) {

		if (veranstaltungskatalog.findAll().iterator().hasNext()) {
			return;
		}
		
		veranstaltungskatalog.save(new EntitiyVeranstaltung("Jongliershow", Money.of(100, EURO), "Artisten jonglieren", 200, VeranstaltungsType.SHOW));
		veranstaltungskatalog.save(new EntitiyVeranstaltung("Jonglieren", Money.of(50, EURO), "Lerne wie Artisten zu jonglieren", 120, VeranstaltungsType.WORKSHOP));
	}

}