package artistenverein.dataInitializer;

import java.time.LocalDateTime;
import java.util.Arrays;

import org.salespointframework.core.DataInitializer;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import artistenverein.kundenverwaltung.RepositoryKunde;
import artistenverein.kundenverwaltung.RepositoryTermin;
import artistenverein.kundenverwaltung.Termin;
import artistenverein.user.Kunde;

@Component
public class InitializerKunde implements DataInitializer{
	
	private final UserAccountManager userAccountManager;
	private final RepositoryKunde kundenRepository;
	private final RepositoryTermin terminRepository;

	@Autowired
	public InitializerKunde(RepositoryKunde kundenRepository, UserAccountManager userAccountManager, RepositoryTermin terminRepository) {

		Assert.notNull(kundenRepository, "CustomerRepository must not be null!");
		Assert.notNull(userAccountManager, "UserAccountManager must not be null!");
		Assert.notNull(terminRepository, "Meetings must not be null!");

		this.kundenRepository = kundenRepository;
		this.userAccountManager = userAccountManager;	
		this.terminRepository = terminRepository;
	}


	@Override
	public void initialize() {
		if (userAccountManager.findByUsername("boss").isPresent()) {
			return;
		}

		UserAccount bossAccount = userAccountManager.create("boss", "123", Role.of("ROLE_BOSS"));
		userAccountManager.save(bossAccount);

		final Role customerRole = Role.of("ROLE_CUSTOMER");

		UserAccount ua1 = userAccountManager.create("hans", "123", customerRole);
		UserAccount ua2 = userAccountManager.create("dextermorgan", "123", customerRole);
		UserAccount ua3 = userAccountManager.create("earlhickey", "123", customerRole);
		UserAccount ua4 = userAccountManager.create("mclovinfogell", "123", customerRole);

		Kunde c1 = new Kunde(ua1, "wurst");
		Kunde c2 = new Kunde(ua2, "Miami-Dade County");
		Kunde c3 = new Kunde(ua3, "Camden County - Motel");
		Kunde c4 = new Kunde(ua4, "Los Angeles");

		// (｡◕‿◕｡)
		// Zu faul um save 4x am Stück aufzurufen :)
		kundenRepository.save(Arrays.asList(c1, c2, c3, c4));
		
		LocalDateTime date = LocalDateTime.of(2017, 12, 24, 19, 30);
		LocalDateTime date1 = LocalDateTime.of(2017, 12, 31, 23, 59);
		
		Termin meeting0 = new Termin("Weihnachtsfeierveranstaltung", date, c1);
		Termin meeting1 = new Termin("Silvesterveranstaltung", date1, c1);
		
		terminRepository.save(Arrays.asList(meeting0, meeting1));
		System.out.println(terminRepository.findAll());
		
	}
}
