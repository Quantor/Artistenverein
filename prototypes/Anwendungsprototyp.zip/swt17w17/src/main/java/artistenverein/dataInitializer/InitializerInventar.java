/*
 * Copyright 2013-2015 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package artistenverein.dataInitializer;

import static org.salespointframework.core.Currencies.*;

import artistenverein.inventarverwaltung.Artistenzeug;
import artistenverein.inventarverwaltung.ProductCatalog;

import org.javamoney.moneta.Money;
import org.salespointframework.core.DataInitializer;
import org.salespointframework.inventory.Inventory;
import org.salespointframework.inventory.InventoryItem;
import org.salespointframework.quantity.Quantity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

/**
 * A {@link DataInitializer} implementation that will create dummy data for the application on application startup.
 * 
 * @author Paul Henke
 * @author Oliver Gierke
 * @see DataInitializer
 */
@Component
public class InitializerInventar implements DataInitializer {

	private final Inventory<InventoryItem> inventory;
	private final ProductCatalog productCatalog;

	@Autowired
	public InitializerInventar(Inventory<InventoryItem> inventory, ProductCatalog productCatalog) {

		Assert.notNull(inventory, "Inventory must not be null!");
		Assert.notNull(productCatalog, "ProductCatalog must not be null!");

		this.inventory = inventory;
		this.productCatalog = productCatalog;
	}

	/* 
	 * (non-Javadoc)
	 * @see org.salespointframework.core.DataInitializer#initialize()
	 */
	@Override
	public void initialize() {
		initializeCatalog(productCatalog, inventory);
	}

	private void initializeCatalog(ProductCatalog productCatalog, Inventory<InventoryItem> inventory) {

		if (productCatalog.findAll().iterator().hasNext()) {
			return;
		}

		productCatalog.save(new Artistenzeug("P1", "lac", Money.of(100, EURO)));
		productCatalog.save(new Artistenzeug("P2", "lac", Money.of(100, EURO)));
		productCatalog.save(new Artistenzeug("P3", "lac", Money.of(100, EURO)));
		productCatalog.save(new Artistenzeug("P4", "lac", Money.of(100, EURO)));
		productCatalog.save(new Artistenzeug("P5", "lac", Money.of(100, EURO)));
		productCatalog.save(new Artistenzeug("P6", "lac", Money.of(100, EURO)));
		productCatalog.save(new Artistenzeug("P7", "lac", Money.of(100, EURO)));
		productCatalog.save(new Artistenzeug("P8", "lac", Money.of(100, EURO)));

		// (｡◕‿◕｡)

		for (Artistenzeug artistenzeug : productCatalog.findAll()) {
			InventoryItem inventoryItem = new InventoryItem(artistenzeug, Quantity.of(10));
			inventory.save(inventoryItem);
		}
	}
}
