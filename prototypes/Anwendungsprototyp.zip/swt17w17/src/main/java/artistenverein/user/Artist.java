package artistenverein.user;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.salespointframework.useraccount.UserAccount;




@Entity
public class Artist {

	
	private @Id @GeneratedValue long id;
	//private String adresse;
	//private String beschreibung;
	

	@OneToOne //
	private UserAccount userAccount;

	@SuppressWarnings("unused")
	private Artist() {}

	public Artist(UserAccount userAccount) {
		this.userAccount = userAccount;
		

	}
	
	
	

	public long getId() {
		return id;
	}
	
	public UserAccount getUserAccount() {
		return userAccount;
	}
	
}
	
