package artistenverein.user;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.salespointframework.useraccount.Password;
import org.salespointframework.useraccount.UserAccount;


@Entity
public class Kunde {

	private @Id @GeneratedValue long id;

	private String adresse;
	
	@OneToOne //
	private UserAccount userAccount;

	public Kunde() {}

	public Kunde(UserAccount userAccount, String adresse) {
		this.userAccount = userAccount;
		this.adresse = adresse;
	}

	public long getId() {
		return id;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	

	public UserAccount getUserAccount() {
		return userAccount;
	}
}
