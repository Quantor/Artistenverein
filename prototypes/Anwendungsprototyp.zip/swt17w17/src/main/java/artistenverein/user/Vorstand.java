package artistenverein.user;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.salespointframework.useraccount.UserAccount;

@Entity
public class Vorstand {

	private @Id @GeneratedValue long id;

	@OneToOne //
	private UserAccount userAccount;

	@SuppressWarnings("unused")
	private Vorstand() {
	}

	public Vorstand(UserAccount userAccount) {
		this.userAccount = userAccount;

	}

	public long getId() {
		return id;
	}

	public UserAccount getUserAccount() {
		return userAccount;
	}

}
