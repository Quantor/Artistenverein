package artistenverein.veranstaltungen;

import org.salespointframework.catalog.Catalog;

import artistenverein.veranstaltungen.EntitiyVeranstaltung;
import artistenverein.veranstaltungen.EntitiyVeranstaltung.VeranstaltungsType;

public interface VeranstaltungsKatalog extends Catalog<EntitiyVeranstaltung> {
	Iterable<EntitiyVeranstaltung> findByType(VeranstaltungsType type) ;
}
