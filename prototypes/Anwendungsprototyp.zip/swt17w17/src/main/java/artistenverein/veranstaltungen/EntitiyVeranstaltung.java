package artistenverein.veranstaltungen;


import javax.persistence.Entity;

import org.javamoney.moneta.Money;
import org.salespointframework.catalog.Product;

@Entity
public class EntitiyVeranstaltung extends Product{
	
	private static final long serialVersionUID = 3602164805477720501L;
	public static enum VeranstaltungsType {
		WORKSHOP,SHOW;
	}
	private String beschreibung;
	private int dauer;
	
	private VeranstaltungsType type;

	@SuppressWarnings("unused")
	private EntitiyVeranstaltung() {}

	public EntitiyVeranstaltung(String titel,Money preis, String beschreibung, int dauer, VeranstaltungsType type) {
		super(titel, preis);
		this.beschreibung = beschreibung;
		this.type =type;
		this.dauer =dauer;
	}
	
	public String getBeschreibung() {
		return beschreibung;
	}
	
	public int getDauer() {
		return dauer;
	}
	
	public VeranstaltungsType getType() {
		return type;
	}


}
