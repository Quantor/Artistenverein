package artistenverein.veranstaltungen;

import org.hibernate.validator.constraints.NotEmpty;

public class FormNeueVeranstaltung {

	@NotEmpty(message = "{NeueVeranstaltung.name.NotEmpty}")
	private String name;

	@NotEmpty(message = "{NeueVeranstaltung.preis.NotEmpty}")
	private String preis;

	@NotEmpty(message = "{NeueVeranstaltung.dauer.NotEmpty}")
	private String dauer;
	
	@NotEmpty(message = "{NeueVeranstaltung.beschreibung.NotEmpty}")
	private String beschreibung;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPreis() {
		return preis;
	}

	public void setPreis(String preis) {
		this.preis = preis;
	}

	public String getBeschreibung() {
		return beschreibung;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}
	
	public String getDauer() {
		return dauer;
	}

	public void setDauer(String dauer) {
		this.dauer = dauer;
	}
}
