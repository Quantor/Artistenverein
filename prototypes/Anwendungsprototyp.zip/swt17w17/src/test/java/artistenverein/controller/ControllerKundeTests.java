package artistenverein.controller;

import static org.junit.Assert.*;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Optional;

import javax.naming.AuthenticationException;
import javax.persistence.OneToOne;

import org.junit.Before;
import org.junit.Test;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountIdentifier;
import org.salespointframework.useraccount.UserAccountManager;
import org.salespointframework.useraccount.web.LoggedIn;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;

import artistenverein.AbstractIntegrationTests;

public class ControllerKundeTests extends AbstractIntegrationTests
{
	@Autowired ControllerKunde controller;
	
	@SuppressWarnings("unchecked")
	@Test
	public void testTermin() 
	{
		Model model = new ExtendedModelMap();
		String returnedView = controller.termine(model, controller.getUserAccountManager().findByUsername("hans").get());
		assertThat(returnedView).isEqualTo("kundenverwaltung/termine");
		Iterable<Object> object = (Iterable<Object>) model.asMap().get("terminListe");
		assertThat(object).hasSize(2);
	}
	
	@Test
	public void testAccountManagement()
	{
		Model model = new ExtendedModelMap();
		UserAccount ua = controller.getUserAccountManager().findByUsername("hans").get();
		System.out.println(ua.getUsername());
		System.out.println(controller.findeKundeZuUserAccount(ua).getUserAccount().getUsername());
		
		controller.accountmanagement(model, ua, "true", "password", "adresse");
		assertEquals("adresse", controller.findeKundeZuUserAccount(ua).getAdresse());		
	}	

}
