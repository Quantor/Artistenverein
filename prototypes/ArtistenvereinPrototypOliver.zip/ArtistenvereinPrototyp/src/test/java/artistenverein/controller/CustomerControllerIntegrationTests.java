package artistenverein.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Optional;

import javax.naming.AuthenticationException;
import javax.persistence.OneToOne;

import org.junit.Before;
import org.junit.Test;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountIdentifier;
import org.salespointframework.useraccount.UserAccountManager;
import org.salespointframework.useraccount.web.LoggedIn;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;

import Artistenverein.controller.CustomerController;
import Artistenverein.model.CustomerRepository;
import Artistenverein.model.MeetingRepository;
import artistenverein.AbstractIntegrationTests;

public class CustomerControllerIntegrationTests extends AbstractIntegrationTests
{
	@Autowired CustomerController controller;

	

	
	@SuppressWarnings("unchecked")
	@Test
	public void testMeeting() 
	{
		Model model = new ExtendedModelMap();
		String returnedView = controller.meetings(model, controller.getUserAccountManager().findByUsername("hans").get());
		assertThat(returnedView).isEqualTo("meetings");
		Iterable<Object> object = (Iterable<Object>) model.asMap().get("meetingList");
		assertThat(object).hasSize(2);
	}
	
	@Test
	public void testAccountManagement()
	{
		Model model = new ExtendedModelMap();
		UserAccount ua = controller.getUserAccountManager().findByUsername("hans").get();
		System.out.println(ua.getUsername());
		System.out.println(controller.findCustomerToUserAccount(ua).getUserAccount().getUsername());
		
		controller.accountmanagement(model, ua, "true", "password", "address");
		assertEquals("address", controller.findCustomerToUserAccount(ua).getAddress());
		
	}
	
	
	

}
