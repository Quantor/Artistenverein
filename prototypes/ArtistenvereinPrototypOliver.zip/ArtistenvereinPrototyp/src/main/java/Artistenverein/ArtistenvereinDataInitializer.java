/*
 * Copyright 2013-2015 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package Artistenverein;


import Artistenverein.model.Customer;
import Artistenverein.model.CustomerRepository;
import Artistenverein.model.Meeting;
import Artistenverein.model.MeetingRepository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.salespointframework.core.DataInitializer;
import org.salespointframework.useraccount.Role;
import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

/**
 * A {@link DataInitializer} implementation that will create dummy data for the application on application startup.
 * 
 * @author Paul Henke
 * @author Oliver Gierke
 * @see DataInitializer
 */
@Component
public class ArtistenvereinDataInitializer implements DataInitializer {

	private final UserAccountManager userAccountManager;
	private final CustomerRepository customerRepository;
	private final MeetingRepository meetingRepository;

	@Autowired
	public ArtistenvereinDataInitializer(CustomerRepository customerRepository, UserAccountManager userAccountManager, MeetingRepository meetingRepository) {

		Assert.notNull(customerRepository, "CustomerRepository must not be null!");
		Assert.notNull(userAccountManager, "UserAccountManager must not be null!");
		Assert.notNull(meetingRepository, "Meetings must not be null!");

		this.customerRepository = customerRepository;
		this.userAccountManager = userAccountManager;	
		this.meetingRepository = meetingRepository;
	}

	/* 
	 * (non-Javadoc)
	 * @see org.salespointframework.core.DataInitializer#initialize()
	 */
	@Override
	public void initialize() {
		initializeUsersAndMeetings(userAccountManager, customerRepository, meetingRepository);
	}


	private void initializeUsersAndMeetings(UserAccountManager userAccountManager, CustomerRepository customerRepository, MeetingRepository meetingRepository) {

		// (｡◕‿◕｡)
		// UserAccounts bestehen aus einem Identifier und eine Password, diese werden auch für ein Login gebraucht
		// Zusätzlich kann ein UserAccount noch Rollen bekommen, diese können in den Controllern und im View dazu genutzt
		// werden
		// um bestimmte Bereiche nicht zugänglich zu machen, das "ROLE_"-Prefix ist eine Konvention welche für Spring
		// Security nötig ist.

		// Skip creation if database was already populated
		if (userAccountManager.findByUsername("boss").isPresent()) {
			return;
		}

		UserAccount bossAccount = userAccountManager.create("boss", "123", Role.of("ROLE_BOSS"));
		userAccountManager.save(bossAccount);

		final Role customerRole = Role.of("ROLE_CUSTOMER");

		UserAccount ua1 = userAccountManager.create("hans", "123", customerRole);
		UserAccount ua2 = userAccountManager.create("dextermorgan", "123", customerRole);
		UserAccount ua3 = userAccountManager.create("earlhickey", "123", customerRole);
		UserAccount ua4 = userAccountManager.create("mclovinfogell", "123", customerRole);

		Customer c1 = new Customer(ua1, "wurst");
		Customer c2 = new Customer(ua2, "Miami-Dade County");
		Customer c3 = new Customer(ua3, "Camden County - Motel");
		Customer c4 = new Customer(ua4, "Los Angeles");

		// (｡◕‿◕｡)
		// Zu faul um save 4x am Stück aufzurufen :)
		customerRepository.save(Arrays.asList(c1, c2, c3, c4));
		
		LocalDateTime date = LocalDateTime.of(2017, 12, 24, 19, 30);
		LocalDateTime date1 = LocalDateTime.of(2017, 12, 31, 23, 59);
		
		Meeting meeting0 = new Meeting("Weihnachtsfeierveranstaltung", date, c1);
		Meeting meeting1 = new Meeting("Silvesterveranstaltung", date1, c1);
		
		meetingRepository.save(Arrays.asList(meeting0, meeting1));
		System.out.println(meetingRepository.findAll());
	}
}
