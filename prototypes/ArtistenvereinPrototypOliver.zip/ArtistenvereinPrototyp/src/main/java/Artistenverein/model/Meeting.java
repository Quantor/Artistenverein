package Artistenverein.model;


import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.salespointframework.useraccount.UserAccount;

@Entity
public class Meeting {
	
	private @Id @GeneratedValue long id;
	
	private String event;
	private LocalDateTime date;
	@OneToOne
	private Customer customer;
	

	public Meeting() {}
	
	public Meeting(String event, LocalDateTime date, Customer customer)
	{
		this.event = event;
		this.date = date;
		this.customer = customer;
	}
	
	public String getEvent()
	{
		return this.event;
	}
	
	public LocalDateTime getDate()
	{
		return this.date;
	}
	
	public Customer getCustomer()
	{
		return this.customer;
	}
}
