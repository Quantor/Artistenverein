package Artistenverein.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


import org.salespointframework.useraccount.UserAccount;
import org.salespointframework.useraccount.UserAccountManager;
import org.salespointframework.useraccount.web.LoggedIn;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import Artistenverein.model.Customer;
import Artistenverein.model.CustomerRepository;
import Artistenverein.model.Meeting;
import Artistenverein.model.MeetingRepository;

@Controller
public class CustomerController 
{
	private final UserAccountManager userAccountManager;
	private final CustomerRepository customerRepository;
	private final MeetingRepository meetingRepository;
	
	
	@Autowired
	public CustomerController(UserAccountManager userAccountManager, CustomerRepository customerRepository, MeetingRepository meetingRepository)
	{
		this.userAccountManager = userAccountManager;
		this.customerRepository = customerRepository;
		this.meetingRepository = meetingRepository;
	}
	
	public UserAccountManager getUserAccountManager()
	{
		return this.userAccountManager;
	}
	
	public CustomerRepository getCustomerRepository()
	{
		return this.customerRepository;
	}
	
	public MeetingRepository getMeetingRepository()
	{
		return this.meetingRepository;
	}
	
	@RequestMapping("/")
	public String home()
	{
		return "home";
	}
	
	@RequestMapping("/meetings")
	public String meetings(Model model, @LoggedIn UserAccount userAccount)
	{
		Iterable<Meeting> meetings = meetingRepository.findAll();
		List<Meeting> meetingsForAccount = new ArrayList<Meeting>();
		for(Iterator<Meeting> it = meetings.iterator(); it.hasNext();)
		{
			Meeting meeting = it.next();
			if(meeting.getCustomer().getUserAccount().getId().equals(userAccount.getId()))
			{
				meetingsForAccount.add(meeting);
			}
		}
		model.addAttribute("meetingList", meetingsForAccount);
		return "meetings";
	}
	
	@RequestMapping(value = "/accountmanagement")
	public String accountmanagement(Model model, @LoggedIn UserAccount userAccount, @RequestParam(value = "changeData", defaultValue = "false") String changeData,
			@RequestParam(value = "password", defaultValue = "false") String password, @RequestParam(value = "address", defaultValue = "false") String address)
	{
		Customer customer = findCustomerToUserAccount(userAccount);
		model.addAttribute("customerList", customer);
		if(changeData.equals("true"))
		{
			userAccountManager.changePassword(userAccount, password);
			customer.setAddress(address);
			
			System.out.println("username:" + userAccount.getUsername());
			System.out.println("address: " + address);
		}
		
		return "accountmanagement";
	}
	
	public Customer findCustomerToUserAccount(UserAccount userAccount)
	{
		Iterator<Customer> customers = customerRepository.findAll().iterator();
		Customer customer = new Customer();
		while(customers.hasNext())
		{
			customer = customers.next();
			if(customer.getUserAccount().getId().equals(userAccount.getId()))
			{
				break;
			}
		}
		return customer;
	}
	
}
